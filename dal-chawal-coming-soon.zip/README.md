# Dal Chawal 🍛

A simple “coming soon” webpage for the **Dal Chawal** blog.

### Live Demo
Coming soon on GitHub Pages!

### Design
- **Font:** Spicy Rice (via Google Fonts)  
- **Background:** `#FFD505`  
- **Text:**
  - "Dal Chawal" — `font-size: 42px`
  - "coming soon" — `font-size: 20px`, color `#B9A025`
